<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function register( UserRegisterRequest $request ) {

        $request->validated();

        $user = User::create([
            "name" => $request["name"],
            "email" => $request["email"],
            "password" => bcrypt( $request["password"]),
            "admin"=>$request["admin"]
        ]);

        return $this->sendResponse( $user->name, "Sikeres regisztráció");
    }

    public function login( UserLoginRequest $request ) {

        $request->validated();

        if( Auth::attempt([ "email" => $request["email"], "password" => $request["password"]])) {

            $actualTime = Carbon::now();
            $authUser = Auth::user();
            $bannedTime = ( new BannerController )->getBannedTime( $authUser->email );
            ( new BannerController )->reSetLoginCounter( $authUser->email );
            
            if( $bannedTime < $actualTime ) {

                (new BannerController ) ->resetBannedtime ( $authUser->email);
                $token = $authUser->createToken( $authUser->email."Token" )->plainTextToken;
                $data["user"] = [ "user" => $authUser->email ];
                $data[ "time" ] = $bannedTime;
                $data["token"] = $token;

                return $this->sendResponse( $data, "Sikeres bejelentkezés");
            }
            else{
                return $this->sendError ( "Autentikációs hiba ",["Következő lehetőség",$bannedTime],401);
            }



        }else {

            $loginCounter = ( new BannerController )->getLoginCounter( $request[ "email" ]);
            if( $loginCounter < 0 ) {

                ( new BannerController )->setLoginCounter( $request[ "email" ]);

            }else {

                ( new BannerController )->setBannedTime( $request[ "email" ]);
            }
            $error = ( new BannerController )->getBannedTime( $request[ "emial" ]);
            $errorMessage = [ "time" => Carbon::now(), "hiba" => "Nem megfelelő email vagy jelszó" ];
            return $this->sendError( $error, [$errorMessage], 401 );
        }
    }

    public function logout() {

        auth( "sanctum" )->user()->currentAccessToken()->delete();
        $name = auth( "sanctum" )->user()->name;

        return $this->sendResponse( $name, "Sikeres kijelentkezés");
    }

    

    public function getTokens() {

        $tokens = DB::table( "personal_access_tokens" )->get();

        return $tokens;
    }
}
