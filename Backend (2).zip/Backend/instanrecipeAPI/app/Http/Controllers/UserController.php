<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Gate;

class UserController extends ResponseController
{
    public function setAdmin(Request $request)
    {
        if (!Gate::allows("super")) {
            return $this->sendError("Autentikációs hiba", "Nincs jogosultsága", 403);
        }
        $request->validate([
            'id' => 'required|integer|exists:users,id',
        ]);

        $user = User::findOrFail($request->id);
        $user->admin = true;
        $user->save();

        return $this->sendResponse($user->only(['id', 'name', 'admin']), "Admin jog megadva");
    }
}
